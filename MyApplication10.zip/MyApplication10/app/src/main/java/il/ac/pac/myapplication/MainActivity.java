package il.ac.pac.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    private EditText cityEditText;
    private TextView tempTextView;
    private Button searchButton;
    private Button detailsButton;
    // המפתח שלך מתמונה 42
    private final String apiKey = "d29b68ddffa658d4e2e08b8ea96df0e6";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // קישור רכיבים מה-XML
        cityEditText = findViewById(R.id.cityEditText);
        tempTextView = findViewById(R.id.tempTextView);
        searchButton = findViewById(R.id.searchButton);
        detailsButton = findViewById(R.id.detailsButton);

        // לחיצה על כפתור חיפוש - משיכת טמפרטורה בסיסית
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String city = cityEditText.getText().toString();
                if (!city.isEmpty()) {
                    fetchWeather(city);
                } else {
                    Toast.makeText(MainActivity.this, "אנא הכנס שם עיר", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // לחיצה על כפתור פרטים - מעבר למסך השני עם שם העיר
        detailsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String city = cityEditText.getText().toString();
                if (!city.isEmpty()) {
                    Intent intent = new Intent(MainActivity.this, DetailsActivity.class);
                    intent.putExtra("CITY_NAME", city);
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, "חפש עיר לפני הצגת פרטים", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void fetchWeather(String city) {
        String url = "https://api.openweathermap.org/data/2.5/weather?q=" + city + "&appid=" + apiKey + "&units=metric";

        StringRequest request = new StringRequest(Request.Method.GET, url,
                response -> {
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        JSONObject main = jsonObject.getJSONObject("main");
                        double temp = main.getDouble("temp");
                        tempTextView.setText(temp + "°C");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                },
                error -> Toast.makeText(this, "עיר לא נמצאה!", Toast.LENGTH_SHORT).show());

        Volley.newRequestQueue(this).add(request);
    }
}