package il.ac.pac.myapplication;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONObject;

public class DetailsActivity extends AppCompatActivity {

    private TextView minTempTv, maxTempTv, cloudsTv, pressureTv, humidityTv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        // קישור ה-Widgets שעיצבת בתמונה 38
        minTempTv = findViewById(R.id.minTempTv);
        maxTempTv = findViewById(R.id.maxTempTv);
        cloudsTv = findViewById(R.id.cloudsTv);
        pressureTv = findViewById(R.id.pressureTv);
        humidityTv = findViewById(R.id.humidityTv);
        Button backButton = findViewById(R.id.backButton);

        // קבלת שם העיר שהועבר מהמסך הראשי
        String city = getIntent().getStringExtra("CITY_NAME");
        if (city != null) {
            fetchFullDetails(city);
        }

        // כפתור חזור למסך הראשי
        backButton.setOnClickListener(v -> finish());
    }

    private void fetchFullDetails(String city) {
        String apiKey = "d29b68ddffa658d4e2e08b8ea96df0e6";
        String url = "https://api.openweathermap.org/data/2.5/weather?q=" + city + "&appid=" + apiKey + "&units=metric";

        StringRequest request = new StringRequest(Request.Method.GET, url,
                response -> {
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        JSONObject main = jsonObject.getJSONObject("main");
                        JSONObject clouds = jsonObject.getJSONObject("clouds");

                        // עדכון הטקסט בכל הרכיבים
                        minTempTv.setText("Min Temp: " + main.getDouble("temp_min") + "°C");
                        maxTempTv.setText("Max Temp: " + main.getDouble("temp_max") + "°C");
                        humidityTv.setText("Humidity: " + main.getInt("humidity") + "%");
                        pressureTv.setText("Pressure: " + main.getInt("pressure") + " hPa");
                        cloudsTv.setText("Clouds: " + clouds.getInt("all") + "%");

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }, null);

        Volley.newRequestQueue(this).add(request);
    }
}